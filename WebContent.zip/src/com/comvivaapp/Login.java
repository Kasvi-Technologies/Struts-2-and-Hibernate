package com.comvivaapp;

public class Login {

	//similarly like main method in plain java
	//struts2 has execute() method as default
	
	private String userName;
	private String password;
	//needs to have setter and getter methods...
	//generate setters and getters using eclipse feature
	
	public String execute(){
		//Business Logic
		return "success";
	}
	
	public String performLogin(){
		
		if("Admin".equals(userName) && 
				"password".equals(password)){
			return "success";
		} else {
			return "failure";
		}
	}



	public String getUserName() {
		return userName;
	}



	public void setUserName(String userName) {
		this.userName = userName;
	}



	public String getPassword() {
		return password;
	}



	public void setPassword(String password) {
		this.password = password;
	}
}
