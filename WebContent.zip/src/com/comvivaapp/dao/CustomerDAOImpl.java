package com.comvivaapp.dao;

import java.util.List;

import org.hibernate.Transaction;
import org.hibernate.Session;

import com.comvivaapp.model.Customer;
import com.googlecode.s2hibernate.struts2.plugin.annotations.SessionTarget;
import com.googlecode.s2hibernate.struts2.plugin.annotations.TransactionTarget;

public class CustomerDAOImpl 
				implements CustomerDAO{
	//Dependency Injection Design Pattern
	
	@SessionTarget
	private Session session;
	
	@TransactionTarget
	private Transaction transaction;	
	
	@Override
	public void saveCustomer(Customer customer) {
		// TODO Auto-generated method stub
		session.save(customer);
	}

	@Override
	public List<Customer> fetchAllCustomers() {
		// TODO Auto-generated method stub
		List<Customer> customerList = 
			session.createQuery("from Customer").list();	
		return customerList;
	}

}
