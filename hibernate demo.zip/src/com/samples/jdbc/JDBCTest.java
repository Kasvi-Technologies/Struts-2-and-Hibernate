package com.samples.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

//JDBC  -> Java database connectivity
public class JDBCTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//1. Load and Register the driver
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("Driver loaded..");
			
			String url ="jdbc:mysql://localhost:3306/comvivadb";
			String username="root";
			String password ="password";
			//String password ="";
			
			//2. Obtain the database connection
			//import java.sql
			Connection con = DriverManager
								.getConnection(url, 
										username, 
										password);
			System.out.println("Connection:" + con);
			
			//create the tables
			
			String createQry="create table employee "
					+ "(id int primary key, "
					+ "name varchar(100), "
					+ "description varchar(100),"
					+ "salary double);";
			
			//import java.sql
			Statement st = con.createStatement();
			st.execute(createQry);
			System.out.println("Table created.......");
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
