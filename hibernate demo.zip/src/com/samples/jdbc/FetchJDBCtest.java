package com.samples.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class FetchJDBCtest {

	public static List<Employee> fetchEmpList(){
		List<Employee> empList = new ArrayList<Employee>();
		try {
			Class.forName("com.mysql.jdbc.Driver");
					
			String url ="jdbc:mysql://localhost:3306/comvivadb";
			String username="root";
			String password ="password";
		
			Connection con = DriverManager
										.getConnection(url, 
												username, 
												password);
			String selectQry = "select * from employee ";
			
			Statement st = con.createStatement();
			ResultSet rs  = st.executeQuery(selectQry);
			
			while (rs.next()){
				
				int id = rs.getInt("id");
				String name = rs.getString("name");
				String description = rs.getString("description");
				double salary = rs.getDouble("salary");
				System.out.println(id + " " + name + " " + salary);
				Employee emp = new Employee(id, name, description,salary);
				empList.add(emp);
			}
			
			System.out.println("done....");
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return empList;
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		List<Employee> empList = fetchEmpList();
		
	}

}
