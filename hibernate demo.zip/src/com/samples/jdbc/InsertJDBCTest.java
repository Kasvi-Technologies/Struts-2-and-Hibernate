package com.samples.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class InsertJDBCTest {

	public static void main(String[] args) {
				
		try {
			Class.forName("com.mysql.jdbc.Driver");
					
			String url ="jdbc:mysql://localhost:3306/comvivadb";
			String username="root";
			String password ="password";
		
			Connection con = DriverManager
										.getConnection(url, 
												username, 
												password);
			String insertQry = "insert into employee "
					+ " values (2, 'Emp2', 'Emp2Desc', 232)";
			
			Statement st = con.createStatement();
			st.executeUpdate(insertQry);
			
			System.out.println("done....");
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
				
	}

}
