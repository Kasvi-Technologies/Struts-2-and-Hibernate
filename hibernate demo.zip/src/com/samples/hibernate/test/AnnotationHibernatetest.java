package com.samples.hibernate.test;

import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.classic.Session;

import com.samples.annotation.User;

public class AnnotationHibernatetest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		AnnotationConfiguration ac = new 
				AnnotationConfiguration();
		ac.configure("/hibernateannotation.cfg.xml");
		
		SessionFactory factory = ac.buildSessionFactory();
		
		Session session = factory.openSession();
		//Session is a Connection
		
		//Session can also be called is a 
		//PersistenceContext
		
		Transaction tx = session.beginTransaction();
		
		User u = new User(); 
		u.setGender("Male");
		u.setName("Comviva Employee1");
		u.setPassword("comviva"); 
		// upto here "u" object is in transient state
		
		//An object which is not associated with 
		//persistence context and does not have primary
		//key (i.e , it does not have reference to 
		// database row)
		
		
		session.save(u);
		
		//u is in Persistence state// Persistence Object
		//An object which is associated with 
		//persistence context and it has the primary
		//key (i.e , it has the reference to 
		// database row)
		
		u.setGender("sdfdsfdsf");// this nfo will be
		//reflected to db...
		
		//all modifications to persistence object
		//will be reflected to db
		
	//	session.delete(u); //will be deleted..
		
		tx.commit();
		session.close(); 
		
		u.setGender("Female"); // it will not be reflected
		//Here, you can call "u" is in detached state
		//Once it was associated with PersistenceContext
		//and it has the database row.
		//but after deletion, you can call that object 
		//is in detached state (it does not have ref to db)
		
	}

}
