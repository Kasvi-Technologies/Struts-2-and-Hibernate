package com.samples.hibernate.test;

import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.classic.Session;

import com.samples.jdbc.Employee;
import com.samples.jdbc.Product;

public class InsertProductHBTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//1. Load the configuration file
		//import org.hibernate.cfg
		Configuration c = new Configuration();
		c.configure("/hibernate.cfg.xml");
		
		//2. Obtain the SessionFactory and Session
		//JDBC -> DataSource -> Pool of Connection Objects
		//Hibernate -> SessonFactory -> Pool of Session Objects
		
		//JDBC Connection = Hibernate Session
		//JDBC DataSource = Hibernate SessionFactory
		
		//import org.hibernate		
		SessionFactory factory = 
						c.buildSessionFactory();
		//import org.hibernate.classic
		Session session = factory.openSession();
		//import org.hibernate.Transation
		Transaction tx = session.beginTransaction();
		Product p = new Product();
		p.setName("asdsad");
		p.setPrice(23213);
		
		session.save(p);// fire the insert query
		tx.commit(); // record will be persisted with this method
		session.close();
		//Hibernate requires Transactions
		
	}

}
