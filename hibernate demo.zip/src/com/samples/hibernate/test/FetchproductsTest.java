package com.samples.hibernate.test;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.classic.Session;
import org.hibernate.criterion.Expression;

import com.samples.jdbc.Product;

public class FetchproductsTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Configuration c = new Configuration();
		c.configure("/hibernate.cfg.xml");
		
		SessionFactory factory = 
						c.buildSessionFactory();
		Session session = factory.openSession();
		
		//fetch all products
		//product is a class name and not the table name
		//HQL-> Hibernate Query Language
		Query query = 
				session.createQuery("from Product"
						+ " where name like 'a%' and "
						+ "price > 10");
		List<Product> productList = query.list();
		System.out.println(productList.size());
		for (Product p : productList){
			System.out.println(p.getName() + " " +p.getPrice());
		}
		
		session.close();
		Session session1 = factory.openSession();
		Criteria criteria = 
				session1.createCriteria(Product.class);
		criteria.add(Expression.like("name", "a%"));
		criteria.add(Expression.between("price", 10, 100));
		//achieve pagination
		
		criteria.setMaxResults(25);
		criteria.setFirstResult(25);
		
		List<Product> productList1 = criteria.list();
		
		
		
	}

}
