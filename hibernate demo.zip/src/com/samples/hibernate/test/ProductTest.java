package com.samples.hibernate.test;

import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.classic.Session;

import com.samples.jdbc.Product;

public class ProductTest {

	public static void main(String[] args) {
		Configuration c = new Configuration();
		c.configure("/hibernate.cfg.xml");
		
		SessionFactory factory = 
						c.buildSessionFactory();
		Session session = factory.openSession();
		
		//select * from product where productid = 2
		//if pk 2 does not found, load method will
		//throw the exception
		
		Product p = 
				(Product) session.load(Product.class, 2);
		
		System.out.println(p.getName() +" " + p.getPrice());
		
		//get method is used to fetch the record based on 
		//primary key simlarly like load
		
		//but get method returns null, if PK does not exists
		
		Product p1 = 
				(Product) session.get(Product.class, 3);
		
		if(p1 != null){
			//BL
			System.out.println(p1.getName() +" " + p1.getPrice());
			
		}
		
		Transaction tx = session.beginTransaction();
		
		p.setName("Modified Product");
		p.setPrice(10000);
		session.delete(p); // update query
		
		tx.commit(); // record will be persisted with this method
		session.close();		

	}

}
